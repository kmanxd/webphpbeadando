<?php
require_once('config.php');
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['username'])) {
        echo "User not logged in";
        exit();
    }

    $username = strtolower($_SESSION['username']);

    $query = "UPDATE users SET win = win + 1 WHERE username = '$username'";

    if ($conn->query($query) === TRUE) {
        echo "Success";
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    echo "Invalid request";
}
?>
<?php
require_once('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

$query = "SELECT username, win FROM users ORDER BY win DESC LIMIT 10";
$result = $conn->query($query);

if (!isset($_SESSION['username'])) {
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style2.css">
    <title>Ranglista</title>
</head>
<body>
    <div class="container">
        <div class="card2">
            <?php
                if ($result->num_rows > 0) {
                    echo '<h2>Ranglista</h2>';
                    echo '<table style="border-spacing: 30px;">';
                    echo '<tr><th>Username</th><th>Wins</th></tr>';
                    
                    while ($row = $result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . $row['username'] . '</td>';
                        echo '<td>' . $row['win'] . '</td>';
                        echo '</tr>';
                    }

                    echo '</table>';
                } else {
                    echo 'No data available';
                }
            ?>
            <a href="home.php"><button class="back-button">Vissza</button></a>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>

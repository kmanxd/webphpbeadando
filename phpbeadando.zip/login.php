<form action="login_process.php" method="post">
    Felhasználónév: <input type="text" name="username" required><br>
    Jelszó: <input type="password" name="password" required><br>
    <input type="submit" value="Bejelentkezés">
</form>
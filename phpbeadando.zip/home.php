<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

if (!isset($_SESSION['username'])) {
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style2.css">
    <title>Kezdőoldal</title>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Üdvözöllek, <?php echo $_SESSION['username']; ?>!</h1>
            <a href="game.php"><button class="game-button">Játék</button></a>
            <a href="logout.php"><button class="logout-button">Kijelentkezés</button></a>
            <a href="leaderboard.php"><button class="leaderboard-button">Ranglista</button></a>
        </div>
    </div>
</body>
</html>

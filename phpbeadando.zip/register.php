<?php
if (isset($_SESSION['user_id'])) {
    header('Location: home.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Regisztráció</title>
    <link rel="stylesheet" href="style2.css">
    <script>
        function validatePassword() {
            const password = document.getElementById('password').value;
            const numberPattern = /\d/;
            const specialCharPattern = /[!@#$%^&*()_+{}\[\]:;<>,.?~\\-]/;

            if (!numberPattern.test(password)) {
                alert('A jelszónak tartalmaznia kell legalább egy számot.');
                return false;
            }

            if (!specialCharPattern.test(password)) {
                alert('A jelszónak tartalmaznia kell legalább egy speciális karaktert.');
                return false;
            }
            document.getElementById('regButton').disabled = true;

            var index = 'index.php';

            window.location.href = index;

            console.log("registration successful");
            return true;
        }
    </script>
</head>
<body>
    <div class="card">
        <form action="register_process.php" method="post" onsubmit="return validatePassword()">
            <label for="username">Felhasználónév:</label>
            <input type="text" name="username" id="username" required>

            <label for="password">Jelszó:</label>
            <input type="password" name="password" id="password" required>

            <button type="submit" id="regButton">Regisztráció</button>
            <a href="index.php"><button type="button">Vissza</button></a>
        </form>
    </div>
</body>
</html>

<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: home.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
    <div class="card">
        <form action="login_process.php" method="post">
            Felhasználónév: <input type="text" name="username" required><br>
            Jelszó: <input type="password" name="password" required><br>
            <button type="submit">Bejelentkezés</button>
            <a href="register.php"><button type="button">Regisztráció</button></a>
        </form>
    </div>
</body>
</html>
<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Uno Játék</title>
</head>
<body>
    <div id="winner-overlay">
        <h2 id="winner">Player Wins!</h2>
        <div class="overlay-button">
            <a href="game.php"><button id="button3" class="button1">Újra</button></a>
            <a href="home.php"><button id="button2" class="button1">Menü</button></a>
        </div>
    </div>
    <div id="game">
        <div id="playerbox">
            <div class="player" id="player">
                <h2 id="playerh2">Player</h2>
                <div class="hand" id="player-hand">
                </div>
            </div>
            <div class="player-controls">
                <button id="control-button">
                    <img src="img/unologo.png" id="gombkep" alt="UNO Logo">
                </button>
            </div>
        </div>
        <div id="pile">
            <div id="discard">
                <h2 id="semmi">.</h2>
                <div id="discard-pile">
                </div>
            </div>
            <div id="draw">
                <h2>Húzópakli</h2>
                <div id="draw-pile"> 
                </div>
            </div>
        </div>
        <div class="player" id="opponent">
            <h2 id="opponenth2">Opponent</h2>
            <div class="hand" id="opponent-hand">
            </div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>

